 // �ּ�
public class postcode {
	private String seq;
    private String postcode;
    private String sido;
    private String gugun;
    private String dong;
    private String ro;
    private String ro_num;
    private String ho;
    private String lat;
    private String lng;

   
    public String getSeq() {
             return seq;
    }

    public void setSeq(String seq) {
             this.seq = seq;
    }

    public String getZipcode() {
             return postcode;
    }

    public void setZipcode(String zipcode) {
             this.postcode = zipcode;
    }

    public String getSido() {
             return sido;
    }

    public void setSido(String sido) {
             this.sido = sido;
    }

    public String getGugun() {
             return gugun;
    }

    public void setGugun(String gugun) {
             this.gugun = gugun;
    }

    public String getDong() {
             return dong;
    }

    public void setDong(String dong) {
             this.dong = dong;
    }

    public String getRo() {
             return ro;
    }

    public void setRo(String ro) {
             this.ro = ro;
    }

    public String getRo_num() {
             return ro_num;
    }

    public void setRo_num(String ro_num) {
             this.ro_num = ro_num;
    }

    public String getHo() {
             return ho;
    }

    public void setHo(String ho) {
             this.ho = ho;
    }
    public String getLat() {
        return lat;
    }

	public void setLat(String lat) {
	        this.lat = lat;
	}  
	public String getLng() {
        return lng;
    }

	public void setLng(String lng) {
	        this.lng = lng;
	}
	
}
