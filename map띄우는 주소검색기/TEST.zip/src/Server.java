import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream.GetField;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.JTable;


public class Server {
	public static void main(String[] args) {
       
        String message = null;       
        ServerSocket serverSocket = null;
        Socket socket = null;
        BufferedWriter bw = null;  //������ ����
        BufferedReader br = null;  //������ �ޱ�
       
        
    
        //���� �غ�
        try {
                 serverSocket = new ServerSocket(7777);      //7777�� ��Ʈ
                 System.out.println("������ �غ�Ǿ����ϴ�.");
        } catch (IOException e) {
                 e.printStackTrace();
        }
              
        while(true){
        try {
                 socket = serverSocket.accept();//����
                 System.out.println("Ŭ���̾�Ʈ�� ����Ǿ����ϴ� - " + socket.getInetAddress());//ip�ּҾ����� �Լ�           
                 br = new BufferedReader(new InputStreamReader(socket.getInputStream()));//input
                 bw = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));                
                 message = br.readLine();   //������
                 System.out.println("������ : " + message);
              
                 
                 //DB ó��==========================================================
                 //DB����
                 postControl controller = new postControl();
                 controller.connectionDB();        
                 ArrayList<postcode> addressList = controller.searchAddress(message); //message=���� �Է��� dong���� �˻��� �ּ�                             
                 String arrAdd = null;
                 String arrAddSum = "========#";
              
                 
                 for(int i = 0 ; i < addressList.size() ; i++){
                        postcode zipcode = addressList.get(i);
                    
                         arrAdd = zipcode.getSeq() + "," + zipcode.getZipcode()+ "," 
                         +zipcode.getSido()+ "," +zipcode.getGugun()+ "," +zipcode.getDong() 
                         + "," + zipcode.getRo() + "," + zipcode.getRo_num() + "," 
                         + zipcode.getHo() +","+ zipcode.getLat()+","+zipcode.getLng()+"#";//�̷��� ���߿� ","�� ���� ���� �� ����,"#"���δ� ���� ������
                                          
                         arrAddSum = arrAddSum + arrAdd;
                                    

                 }   
                 
                 System.out.println(arrAddSum);
                 bw.write(arrAddSum + "\n");
                 bw.flush();       //��� ���۸� ���� �޼���
                 
        //DB����
        controller.disconnectionDB();
        }
        catch (IOException e) {
                 e.printStackTrace();
        } finally {
                 if ( br != null) try{br.close();} catch(IOException e){}
                 if ( bw != null) try{bw.close();} catch(IOException e){}
                 if ( socket != null) try{socket.close();} catch(IOException e){}
        }
        }
}
}

